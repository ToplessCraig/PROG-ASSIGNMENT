/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main;

/**
 *
 * @author Student
 */
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login userLogin = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976");

        System.out.println("=== PART 1: ACCOUNT REGISTRATION ===");

        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();

     
        String username;
        while (true) {
            System.out.print("Enter Username (must contain '_' and <= 5 characters): ");
            username = scanner.nextLine();
            if (userLogin.checkUserName(username)) {
                System.out.println("Username successfully captured.");
                break;
            } else {
                System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
            }
        }

        String password;
        while (true) {
            System.out.print("Enter Password (min 8 characters, 1 uppercase, 1 number, 1 special character): ");
            password = scanner.nextLine();
            if (userLogin.checkPasswordComplexity(password)) {
                System.out.println("Password successfully captured.");
                break;
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
        }

        String cellNumber;
        while (true) {
            System.out.print("Enter Cell Phone Number (with international code, e.g. +27123456789): ");
            cellNumber = scanner.nextLine();
            if (userLogin.checkCellPhoneNumber(cellNumber)) {
                System.out.println("Cell number successfully captured.");
                break;
            } else {
                System.out.println("Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.");
            }
        }

        userLogin.registerUser(username, password, cellNumber, firstName, lastName);

        System.out.println("\n=== LOGIN FEATURE ===");
        System.out.print("Enter Username to Login: ");
        String loginUsername = scanner.nextLine();

        System.out.print("Enter Password to Login: ");
        String loginPassword = scanner.nextLine();

        boolean isSuccess = userLogin.loginUser(loginUsername, loginPassword);
        System.out.println(userLogin.returnLoginStatus(isSuccess));

        scanner.close();
    }
}
