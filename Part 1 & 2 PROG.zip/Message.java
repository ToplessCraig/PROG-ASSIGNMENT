/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

/**
 *
 * @author Student
 */

import java.util.regex.Pattern;

/**
 * Represents a chat message containing a payload, recipient phone number,
 * and transmission delivery status flags [1, 2].
 */
public class Message {

    private String recipientCellNumber;
    private String messagePayload;
    private boolean isSent;
    private boolean isReceived;
    private boolean isRead;

    // Regex: Ensures the cell phone number starts with an international country code (+) [4]
    private static final String CELL_PHONE_REGEX = "^\\+\\d{1,3}\\d{8,10}$";

    public Message() {
        this.isSent = false;
        this.isReceived = false;
        this.isRead = false;
    }

    public Message(String recipientCellNumber, String messagePayload) {
        this.recipientCellNumber = recipientCellNumber;
        this.messagePayload = messagePayload;
        this.isSent = false;
        this.isReceived = false;
        this.isRead = false;
    }

    /**
     * Checks if the recipient cell number contains an international country code (+) [4].
     */
    public boolean validateRecipientNumber(String cellNumber) {
        if (cellNumber == null) {
            return false;
        }
        return Pattern.matches(CELL_PHONE_REGEX, cellNumber);
    }

    /**
     * Transmits the message payload to the recipient if the cell number format is valid,
     * updating the Sent and Received status flags [1].
     */
    public String sendMessage(String recipientCellNumber, String messagePayload) {
        if (!validateRecipientNumber(recipientCellNumber)) {
            this.isSent = false;
            this.isReceived = false;
            return "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
        }

        this.recipientCellNumber = recipientCellNumber;
        this.messagePayload = messagePayload;
        this.isSent = true;
        this.isReceived = true; // Simulated successful transmission [1]
        return "Message successfully sent to " + recipientCellNumber;
    }

    /**
     * Marks the delivered message as read [1, 2].
     */
    public boolean markAsRead() {
        if (this.isSent && this.isReceived) {
            this.isRead = true;
        }
        return this.isRead;
    }

    // Getters
    public String getRecipientCellNumber() {
        return recipientCellNumber;
    }

    public String getMessagePayload() {
        return messagePayload;
    }

    public boolean isSent() {
        return isSent;
    }

    public boolean isReceived() {
        return isReceived;
    }

    public boolean isRead() {
        return isRead;
    }
}