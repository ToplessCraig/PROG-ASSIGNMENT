/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main;

/**
 *
 * @author Student
 */
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login userLogin = new Login();

        System.out.println("===  ACCOUNT REGISTRATION ===");

        System.out.print("Enter First Name: ");
        String firstName = input.nextLine();

        System.out.print("Enter Last Name: ");
        String lastName = input.nextLine();

     
        String username;
        while (true) {
            System.out.print("Enter Username (must contain '_' and <= 5 characters): ");
            username = input.nextLine();
            if (userLogin.checkUserName(username)) {
                System.out.println("Username successfully captured.");
                break;
            } else {
                System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
            }
        }

        String password;
        while (true) {
            System.out.print("Enter Password (min 8 characters, 1 uppercase, 1 number, 1 special character): ");
            password = input.nextLine();
            if (userLogin.checkPasswordComplexity(password)) {
                System.out.println("Password successfully captured.");
                break;
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
        }

        String cellNumber;
        while (true) {
            System.out.print("Enter Cell Phone Number (with international code, e.g. +27123456789): ");
            cellNumber = input.nextLine();
            if (userLogin.checkCellPhoneNumber(cellNumber)) {
                System.out.println("Cell number successfully captured.");
                break;
            } else {
                System.out.println("Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.");
            }
        }

        userLogin.registerUser(username, password, cellNumber, firstName, lastName);

        System.out.println("\n=== LOGIN FEATURE ===");
        System.out.print("Enter Username to Login: ");
        String loginUsername = input.nextLine();

        System.out.print("Enter Password to Login: ");
        String loginPassword = input.nextLine();

        boolean isSuccess = userLogin.loginUser(loginUsername, loginPassword);
        System.out.println(userLogin.returnLoginStatus(isSuccess));
        
         Scanner scanner = new Scanner(System.in);
        boolean keepSending = true;

        System.out.println("=========================================");
        System.out.println("===  SENDING MESSAGES FEATURE ===");
        System.out.println("=========================================");

        // Loop to allow sending multiple messages [2, 3]
        while (keepSending) {
            Message chatMessage = new Message();

            System.out.print("\nEnter Recipient Cell Number (e.g., +27838968976): ");
            String recipient = scanner.nextLine();

            System.out.print("Enter Message Payload: ");
            String payload = scanner.nextLine();

            String sendResult = chatMessage.sendMessage(recipient, payload);
            System.out.println(sendResult);

            if (chatMessage.isSent()) {
                System.out.println("Status Flags -> Sent: " + chatMessage.isSent()
                        + " | Received: " + chatMessage.isReceived()
                        + " | Read: " + chatMessage.markAsRead());
            }

            System.out.print("\nWould you like to send another message? (yes/no): ");
            String response = scanner.nextLine();
            if (!response.equalsIgnoreCase("yes")) {
                keepSending = false;
            }
        }

        System.out.println("Exiting Messaging Feature. Goodbye!");
        scanner.close();
    }
        
       
    }

